package com.example.taximeter;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;

public class SettingsActivity extends Activity {
    TariffConfig c; EditText base,baseM,df,dm,tf,ts,low,np,npp,op,ns,ne; Switch night,out;
    EditText e(String label,String v,LinearLayout p, boolean decimal){
        TextView l=new TextView(this); l.setText(label); l.setTextSize(15); l.setPadding(0,14,0,4); p.addView(l);
        EditText x=new EditText(this); x.setText(v); x.setTextSize(17); x.setSingleLine(true);
        x.setInputType(decimal ? InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL : InputType.TYPE_CLASS_NUMBER);
        p.addView(x); return x;
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b); c=new TariffConfig(this);
        ScrollView sv=new ScrollView(this); LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(28,24,28,30); sv.addView(p);
        TextView h=new TextView(this); h.setText("요금 체계 커스터마이징"); h.setTextSize(25); h.setGravity(Gravity.CENTER_VERTICAL); p.addView(h);
        TextView info=new TextView(this); info.setText("기본거리 이후에는 거리요금이 붙고, 설정한 병산 기준속도 미만에서는 시간요금도 함께 병산됩니다. 서울 중형택시 기본값은 15.72km/h입니다."); info.setPadding(0,8,0,16); p.addView(info);
        base=e("기본요금 (원)",""+c.baseFare(),p,false);
        baseM=e("기본요금 포함거리 (m)",""+c.baseDistanceM(),p,false);
        df=e("주간 거리 단위요금 (원)",""+c.distanceUnitFare(),p,false);
        dm=e("거리 단위 (m)",""+c.distanceUnitM(),p,false);
        tf=e("주간 시간 단위요금 (원)",""+c.timeUnitFare(),p,false);
        ts=e("시간 단위 (초)",""+c.timeUnitSec(),p,false);
        low=e("시간·거리 부분 동시병산 기준속도 (km/h)",""+c.lowSpeedKmh(),p,true);
        np=e("심야 20% 구간 할증률 (%)",""+c.nightPct(),p,false);
        npp=e("심야 40% 구간 할증률 (%)",""+c.nightPeakPct(),p,false);
        op=e("시계외 할증 (%)",""+c.outPct(),p,false);
        ns=e("심야 시작 (HH:mm)",c.nightStart(),p,false); ns.setInputType(InputType.TYPE_CLASS_DATETIME|InputType.TYPE_DATETIME_VARIATION_TIME);
        ne=e("심야 종료 (HH:mm)",c.nightEnd(),p,false); ne.setInputType(InputType.TYPE_CLASS_DATETIME|InputType.TYPE_DATETIME_VARIATION_TIME);
        TextView ninfo=new TextView(this); ninfo.setText("서울 중형택시 기본값: 22~23시·02~04시는 20%, 23~02시는 40%. 심야 기본·거리·시간요금은 이 비율을 적용하고 10/100원 단위로 반올림합니다. 심야·시계외 토글은 메인 화면에서 운행 중에도 변경할 수 있으며, 이미 누적된 요금은 변경되지 않습니다."); ninfo.setPadding(0,6,0,12); p.addView(ninfo);
        Button save=new Button(this); save.setText("저장"); save.setMinHeight(64); p.addView(save);
        save.setOnClickListener(v->{
            try{
                c.save(Integer.parseInt(base.getText().toString()),Integer.parseInt(baseM.getText().toString()),Integer.parseInt(df.getText().toString()),Integer.parseInt(dm.getText().toString()),Integer.parseInt(tf.getText().toString()),Integer.parseInt(ts.getText().toString()),Float.parseFloat(low.getText().toString()),Integer.parseInt(np.getText().toString()),Integer.parseInt(npp.getText().toString()),Integer.parseInt(op.getText().toString()),ns.getText().toString(),ne.getText().toString(),c.autoNight()); Toast.makeText(this,"저장되었습니다",Toast.LENGTH_SHORT).show(); finish();
            }catch(Exception ex){Toast.makeText(this,"숫자/시간 형식을 확인하세요",Toast.LENGTH_SHORT).show();}
        });
        setContentView(sv);
    }
}
