package com.example.taximeter;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.*;
import androidx.annotation.NonNull;
import com.google.android.gms.location.*;
import java.util.*;

public class MeterService extends Service {
    private FusedLocationProviderClient client;
    private Location last;
    private long gapStart=0;
    private long lastLocationElapsed=0;
    private double total=0, gapDistance=0;
    private float lastSpeed=0;

    // Fare is accumulated incrementally. Toggling surcharges never recalculates
    // money that has already been charged.
    private int accumulatedFare=0;
    private int chargedDistanceUnits=0;
    private int chargedTimeUnits=0;
    private boolean fareStarted=false;

    // Time-fare accounting is deliberately independent from GPS callback frequency.
    private double lowSpeedSeconds=0.0;
    private boolean lowSpeedActive=false;
    private long lastTimerElapsed=0;
    private final Handler timerHandler=new Handler(Looper.getMainLooper());
    private static final long TIMER_INTERVAL_MS=250L;
    private static final double MIN_GAP=10.0, MAX_GAP_SEC=180.0, MAX_GAP_DISTANCE=5000.0;

    private final Runnable meterTimer=new Runnable(){
        @Override public void run(){
            long now=SystemClock.elapsedRealtime();
            updateTimeCounter(now);
            if(last!=null){
                TariffConfig c=new TariffConfig(MeterService.this);
                send(last,c);
            }
            timerHandler.postDelayed(this,TIMER_INTERVAL_MS);
        }
    };

    private final LocationCallback cb=new LocationCallback(){
        @Override public void onLocationResult(@NonNull LocationResult r){
            for(Location l:r.getLocations()) handle(l);
        }
    };

    @Override public void onCreate(){
        super.onCreate();
        client=LocationServices.getFusedLocationProviderClient(this);
        try { startForeground(77,notification("GPS 위치를 기다리는 중")); }
        catch(Exception e){ sendError("포그라운드 서비스 시작 실패"); stopSelf(); return; }
        request();
        lastTimerElapsed=SystemClock.elapsedRealtime();
        timerHandler.postDelayed(meterTimer,TIMER_INTERVAL_MS);
    }

    private void request(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            sendError("위치 권한이 없습니다"); stopSelf(); return;
        }
        LocationRequest req=new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,1000)
                .setMinUpdateIntervalMillis(500).setMaxUpdateDelayMillis(2000).build();
        try{
            client.requestLocationUpdates(req,cb,Looper.getMainLooper());
            client.getLastLocation().addOnSuccessListener(l->{ if(l!=null && last==null) handle(l); });
        }catch(SecurityException e){ sendError("위치 권한이 차단되어 있습니다"); stopSelf(); }
    }

    private void handle(Location l){
        if(l==null) return;
        long now=SystemClock.elapsedRealtime();
        TariffConfig c=new TariffConfig(this);
        float acc=l.hasAccuracy()?l.getAccuracy():999f;

        if(last==null){
            last=l;
            lastLocationElapsed=now;
            lastTimerElapsed=now;
            updateSpeedFromLocation(l,0);
            initializeFare(c);
            send(l,c);
            return;
        }

        // First account for time that elapsed under the previous speed state.
        updateTimeCounter(now);
        double dt=Math.max(0,(now-lastLocationElapsed)/1000.0);

        if(acc>80f){
            if(gapStart==0) gapStart=lastLocationElapsed;
            // Keep the last valid speed state while GPS is temporarily unavailable.
            // updateTimeCounter() caps this gap at MAX_GAP_SEC.
            send(l,c);
            return;
        }

        if(gapStart>0){
            double gapSec=Math.max(0,(now-gapStart)/1000.0);
            float straight=last.distanceTo(l);
            double expected=Math.max(0,lastSpeed)*gapSec;
            boolean accepted=gapSec<=MAX_GAP_SEC && straight>=MIN_GAP && straight<=MAX_GAP_DISTANCE;
            if(accepted){
                double ratio=expected>1?straight/expected:1;
                accepted=expected<1 || (ratio>=0.35 && ratio<=2.8);
            }
            if(accepted){ total+=straight; gapDistance+=straight; }
            gapStart=0;
        }else{
            float d=last.distanceTo(l);
            if(d>=MIN_GAP && d<1000 && dt<15) total+=d;
        }

        updateSpeedFromLocation(l,dt);
        last=l;
        lastLocationElapsed=now;
        lastTimerElapsed=now;
        send(l,c);
    }

    private void updateSpeedFromLocation(Location l,double dt){
        if(l.hasSpeed()) lastSpeed=Math.max(0,l.getSpeed());
        else if(dt>0 && dt<=15 && last!=null) lastSpeed=Math.max(0,(float)(last.distanceTo(l)/dt));
        lowSpeedActive=lastSpeed*3.6 < new TariffConfig(this).lowSpeedKmh();
        // A fresh valid GPS sample establishes a new low-speed state. The timer
        // itself, not GPS callbacks, measures the elapsed time.
    }

    private void updateTimeCounter(long now){
        if(lastTimerElapsed<=0){ lastTimerElapsed=now; return; }
        long elapsedMs=Math.max(0,now-lastTimerElapsed);
        if(elapsedMs==0) return;

        boolean withinGpsWindow=gapStart==0 || (now-gapStart)<=MAX_GAP_SEC*1000.0;
        if(lowSpeedActive && withinGpsWindow){
            lowSpeedSeconds += elapsedMs/1000.0;
        }
        lastTimerElapsed=now;

        // Once GPS has been absent for too long, stop time billing until a valid
        // location establishes a new state. This prevents indefinite billing.
        if(gapStart>0 && (now-gapStart)>MAX_GAP_SEC*1000.0){
            lowSpeedActive=false;
        }
    }

    private int roundTo(int value,int unit){ return unit<=1?value:Math.round(value/(float)unit)*unit; }

    private int nightPercent(TariffConfig c){
        if(!c.autoNight()) return 0;
        Calendar now=Calendar.getInstance();
        int mins=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE);
        if(mins>=1380 || mins<120) return c.nightPeakPct();
        if(mins>=1320 || mins<240) return c.nightPct();
        return 0;
    }

    private int[] appliedRates(TariffConfig c){
        int np=nightPercent(c), base=c.baseFare(), df=c.distanceUnitFare(), tf=c.timeUnitFare();
        if(np>0){
            base=roundTo(Math.round(base*(1+np/100f)),100);
            df=roundTo(Math.round(df*(1+np/100f)),10);
            tf=roundTo(Math.round(tf*(1+np/100f)),10);
        }
        return new int[]{base,df,tf,np};
    }

    private int nightPercentNow(TariffConfig c){
        if(!c.autoNight()) return 0;
        Calendar now=Calendar.getInstance();
        int mins=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE);
        if(mins>=1380 || mins<120) return c.nightPeakPct();
        if(mins>=1320 || mins<240) return c.nightPct();
        return 0;
    }

    private int applyNight(int amount,int pct){
        if(pct<=0) return amount;
        return roundTo(Math.round(amount*(1+pct/100f)), amount>=1000?100:10);
    }

    private int applyOut(int amount,TariffConfig c,int nightPct){
        if(!c.outOfArea()) return amount;
        int extra=Math.min(c.outPct(),Math.max(0,60-nightPct));
        if(extra<=0) return amount;
        return roundTo(Math.round(amount*(1+extra/100f)),10);
    }

    private void initializeFare(TariffConfig c){
        if(fareStarted) return;
        int nightPct=nightPercentNow(c);
        // Base fare is fixed at the moment the meter starts. Therefore turning
        // the night toggle on/off later cannot retroactively change it.
        accumulatedFare=applyNight(c.baseFare(),nightPct);
        fareStarted=true;
        chargedDistanceUnits=0;
        chargedTimeUnits=0;
    }

    private void updateAccumulatedFare(TariffConfig c){
        if(!fareStarted) initializeFare(c);

        double beyond=Math.max(0,total-c.baseDistanceM());
        int distanceUnits=(int)Math.floor(beyond/c.distanceUnitM());
        int timeUnits=(int)Math.floor(lowSpeedSeconds/(double)c.timeUnitSec());

        // Each newly earned unit is charged using the toggle state and tariff
        // that are active at that moment. Existing fare is never recalculated.
        while(chargedDistanceUnits<distanceUnits){
            int np=nightPercentNow(c);
            int unit=c.distanceUnitFare();
            unit=applyNight(unit,np);
            unit=applyOut(unit,c,np);
            accumulatedFare+=unit;
            chargedDistanceUnits++;
        }
        while(chargedTimeUnits<timeUnits){
            int np=nightPercentNow(c);
            int unit=c.timeUnitFare();
            unit=applyNight(unit,np);
            unit=applyOut(unit,c,np);
            accumulatedFare+=unit;
            chargedTimeUnits++;
        }
    }

    private int calcFare(TariffConfig c){
        updateAccumulatedFare(c);
        return roundTo(accumulatedFare,10);
    }

    private void send(Location l,TariffConfig c){
        int[] rates=appliedRates(c);
        Intent i=new Intent("METER_UPDATE");
        i.setPackage(getPackageName());
        i.putExtra("fare",calcFare(c));
        i.putExtra("distance",total/1000.0);
        i.putExtra("speed",lastSpeed*3.6);
        i.putExtra("gap",gapDistance/1000.0);

        double beyond=Math.max(0,total-c.baseDistanceM());
        boolean basePhase=total<c.baseDistanceM();
        int dMax=basePhase?Math.max(1,c.baseDistanceM()):Math.max(1,c.distanceUnitM());
        int dProgress;
        if(basePhase) dProgress=(int)Math.min(c.baseDistanceM(),Math.floor(total));
        else dProgress=(int)Math.floor(beyond%c.distanceUnitM());
        int dRemain=Math.max(0,dMax-dProgress);
        if(dRemain==0) dRemain=dMax;
        i.putExtra("basePhase",basePhase); i.putExtra("distanceRemain",dRemain); i.putExtra("distanceMax",dMax); i.putExtra("distanceProgress",dMax-dRemain);

        int tMax=Math.max(1,c.timeUnitSec());
        int tProgress=(int)Math.floor(lowSpeedSeconds%tMax);
        int tRemain=Math.max(0,(int)Math.ceil(tMax-(lowSpeedSeconds%tMax)));
        if(tRemain<=0)tRemain=tMax;
        boolean timeActive=lowSpeedActive;
        i.putExtra("timeActive",timeActive); i.putExtra("timeRemain",tRemain); i.putExtra("timeMax",tMax); i.putExtra("timeProgress",Math.min(tMax,tMax-tRemain));

        String status=l.hasAccuracy()&&l.getAccuracy()<=80?"GPS 정상":"GPS 신호 불량 · 보정 대기";
        i.putExtra("gps",status+" · ±"+(int)(l.hasAccuracy()?l.getAccuracy():0)+" m");
        String mode=timeActive?"● 시간·거리 동시병산 중":"● 거리 병산 중";
        if(gapStart>0) mode="● GPS 신호 보정 대기";
        i.putExtra("mode",mode);
        String night=rates[3]>0?" · 심야 "+rates[3]+"%":"";
        String out=c.outOfArea()?" · 시계외 "+c.outPct()+"%":"";
        i.putExtra("tariffSummary",String.format(Locale.KOREA,
                "현재 적용 · 기본 %,d원 / %,d m  ·  거리 %,d원 / %,d m  ·  시간 %,d원 / %d초%s%s",
                rates[0],c.baseDistanceM(),rates[1],c.distanceUnitM(),rates[2],c.timeUnitSec(),night,out));
        sendBroadcast(i);
    }

    private void sendError(String msg){
        Intent i=new Intent("METER_ERROR"); i.setPackage(getPackageName()); i.putExtra("message",msg); sendBroadcast(i); }

    private Notification notification(String s){
        String ch="meter"; NotificationManager nm=getSystemService(NotificationManager.class);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"Taxi Meter",NotificationManager.IMPORTANCE_LOW));
        return new Notification.Builder(this,ch).setContentTitle("Korea Taxi Meter").setContentText(s).setSmallIcon(android.R.drawable.ic_menu_mylocation).build();
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){ return START_NOT_STICKY; }
    @Override public void onDestroy(){
        timerHandler.removeCallbacks(meterTimer);
        if(client!=null) client.removeLocationUpdates(cb);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i){return null;}
}
