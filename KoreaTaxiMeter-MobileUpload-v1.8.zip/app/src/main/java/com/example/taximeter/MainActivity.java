package com.example.taximeter;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 10;
    private static final int REQ_NOTIFICATIONS = 11;

    TextView fare, dist, speed, gps, gap, distanceTitle, distanceRemain, timeTitle, timeRemain, mode, tariffSummary;
    ProgressBar distanceBar, timeBar;
    Button start, stop, settings;
    Switch nightToggle, outToggle;
    private boolean startAfterPermission = false;

    private final BroadcastReceiver meterReceiver = new BroadcastReceiver(){
        @Override public void onReceive(Context c, Intent i){
            if(!"METER_UPDATE".equals(i.getAction())) return;
            updateFromMeter(i);
        }
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        buildUi();
        IntentFilter f=new IntentFilter("METER_UPDATE");
        if(Build.VERSION.SDK_INT>=33) registerReceiver(meterReceiver,f,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(meterReceiver,f);
        settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        start.setOnClickListener(v->startMeter());
        stop.setOnClickListener(v->stopService(new Intent(this,MeterService.class)));
        refreshTariffDisplay();
    }

    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(10),dp(14),dp(10)); root.setBackgroundColor(Color.WHITE);
        ScrollView scroll=new ScrollView(this);
        LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(0,0,0,dp(8));
        scroll.addView(content);

        LinearLayout top=new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=t("Korea Taxi Meter 1.8",22); top.addView(title,new LinearLayout.LayoutParams(0,dp(54),1));
        settings=new Button(this); settings.setText("⚙ 요금 설정"); top.addView(settings,new LinearLayout.LayoutParams(-2,dp(54))); content.addView(top);

        LinearLayout toggles=new LinearLayout(this); toggles.setOrientation(LinearLayout.HORIZONTAL); toggles.setGravity(Gravity.CENTER_VERTICAL);
        nightToggle=new Switch(this); nightToggle.setText("심야할증"); nightToggle.setTextSize(15);
        outToggle=new Switch(this); outToggle.setText("시계외할증"); outToggle.setTextSize(15);
        toggles.addView(nightToggle,new LinearLayout.LayoutParams(0,dp(52),1)); toggles.addView(outToggle,new LinearLayout.LayoutParams(0,dp(52),1));
        content.addView(toggles);
        nightToggle.setOnCheckedChangeListener((button,checked)->{ if(!button.isPressed()) return; new TariffConfig(this).setAutoNight(checked); });
        outToggle.setOnCheckedChangeListener((button,checked)->{ if(!button.isPressed()) return; new TariffConfig(this).setOutOfArea(checked); });

        fare=t("4,800 원",60); fare.setGravity(Gravity.CENTER); fare.setTypeface(null,android.graphics.Typeface.BOLD);
        content.addView(fare,new LinearLayout.LayoutParams(-1,dp(130)));

        mode=t("● 운행 대기",15); mode.setGravity(Gravity.CENTER); content.addView(mode,new LinearLayout.LayoutParams(-1,dp(28)));
        tariffSummary=t("설정값을 불러오는 중",13); tariffSummary.setGravity(Gravity.CENTER); tariffSummary.setPadding(0,0,0,dp(8)); content.addView(tariffSummary);

        LinearLayout dBox=box();
        distanceTitle=t("기본요금 포함거리까지",15); distanceTitle.setGravity(Gravity.CENTER);
        distanceRemain=t("1,600 m",34); distanceRemain.setGravity(Gravity.CENTER); distanceRemain.setTypeface(null,android.graphics.Typeface.BOLD);
        distanceBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); distanceBar.setMax(1600); distanceBar.setProgress(0);
        dBox.addView(distanceTitle); dBox.addView(distanceRemain,new LinearLayout.LayoutParams(-1,dp(48))); dBox.addView(distanceBar,new LinearLayout.LayoutParams(-1,dp(20)));
        content.addView(dBox,new LinearLayout.LayoutParams(-1,dp(118)));

        LinearLayout tBox=box();
        timeTitle=t("시간요금 병산 대기",15); timeTitle.setGravity(Gravity.CENTER);
        timeRemain=t("—",34); timeRemain.setGravity(Gravity.CENTER); timeRemain.setTypeface(null,android.graphics.Typeface.BOLD);
        timeBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); timeBar.setMax(30); timeBar.setProgress(0);
        tBox.addView(timeTitle); tBox.addView(timeRemain,new LinearLayout.LayoutParams(-1,dp(48))); tBox.addView(timeBar,new LinearLayout.LayoutParams(-1,dp(20)));
        content.addView(tBox,new LinearLayout.LayoutParams(-1,dp(118)));

        dist=t("주행거리 0.00 km",16); speed=t("속도 0.0 km/h",16); gps=t("GPS 대기",14); gap=t("GPS 보정거리 0.00 km",14);
        content.addView(dist); content.addView(speed); content.addView(gps); content.addView(gap);

        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); buttons.setPadding(0,dp(8),0,dp(4));
        start=new Button(this); start.setText("운행 시작"); stop=new Button(this); stop.setText("운행 종료");
        start.setTextSize(18); stop.setTextSize(18);
        buttons.addView(start,new LinearLayout.LayoutParams(0,dp(64),1)); buttons.addView(stop,new LinearLayout.LayoutParams(0,dp(64),1)); content.addView(buttons);

        TextView note=t("실제 택시미터기처럼 다음 요금까지 남은 거리·시간을 실제 누적값으로 표시합니다. 0에 도달하면 요금 단위가 증가하고 다시 카운트합니다.",12);
        note.setPadding(0,dp(8),0,dp(8)); content.addView(note);

        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void startMeter(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            startAfterPermission=true;
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION);
            return;
        }
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            startAfterPermission=true;
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS);
            return;
        }
        LocationManager lm=(LocationManager)getSystemService(LOCATION_SERVICE);
        boolean enabled=false;
        if(lm!=null){
            try { enabled=lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER); }
            catch(Exception ignored){}
        }
        if(!enabled){
            Toast.makeText(this,"위치 서비스를 켜주세요.",Toast.LENGTH_LONG).show();
            try { startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); } catch(Exception ignored){}
            return;
        }
        try{
            Intent in=new Intent(this,MeterService.class);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(in); else startService(in);
            mode.setText("● GPS 연결 중…");
        }catch(Exception e){
            Toast.makeText(this,"미터기 시작 실패: "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==REQ_LOCATION){
            boolean ok=grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED;
            if(ok && startAfterPermission){ startAfterPermission=false; startMeter(); }
            else if(!ok) Toast.makeText(this,"정확한 위치 권한이 필요합니다.",Toast.LENGTH_LONG).show();
        }else if(requestCode==REQ_NOTIFICATIONS){
            startAfterPermission=false;
            startMeter();
        }
    }

    @Override protected void onResume(){ super.onResume(); refreshTariffDisplay(); }

    private void refreshTariffDisplay(){
        TariffConfig c=new TariffConfig(this);
        if(!isMeterRunning()){
            fare.setText(String.format(Locale.KOREA,"%,d 원",c.baseFare()));
        }
        distanceTitle.setText("기본요금 포함거리까지");
        distanceRemain.setText(String.format(Locale.KOREA,"%,d m",c.baseDistanceM()));
        distanceBar.setMax(Math.max(1,c.baseDistanceM())); distanceBar.setProgress(0);
        timeTitle.setText("시간요금 병산 대기"); timeRemain.setText("—"); timeBar.setMax(Math.max(1,c.timeUnitSec())); timeBar.setProgress(0);
        nightToggle.setChecked(c.autoNight());
        outToggle.setChecked(c.outOfArea());
        tariffSummary.setText(String.format(Locale.KOREA,
                "설정 적용 · 기본 %,d원 / %,d m  ·  거리 %,d원 / %,d m  ·  시간 %,d원 / %d초",
                c.baseFare(),c.baseDistanceM(),c.distanceUnitFare(),c.distanceUnitM(),c.timeUnitFare(),c.timeUnitSec()));
    }

    private boolean isMeterRunning(){
        android.app.ActivityManager am=(android.app.ActivityManager)getSystemService(ACTIVITY_SERVICE);
        if(am==null) return false;
        for(android.app.ActivityManager.RunningServiceInfo info:am.getRunningServices(Integer.MAX_VALUE)){
            if(MeterService.class.getName().equals(info.service.getClassName())) return true;
        }
        return false;
    }

    private void updateFromMeter(Intent i){
        fare.setText(String.format(Locale.KOREA,"%,d 원",i.getIntExtra("fare",0)));
        dist.setText(String.format(Locale.KOREA,"주행거리 %.2f km",i.getDoubleExtra("distance",0)));
        speed.setText(String.format(Locale.KOREA,"속도 %.1f km/h",i.getDoubleExtra("speed",0)));
        gps.setText(i.getStringExtra("gps"));
        gap.setText(String.format(Locale.KOREA,"GPS 보정거리 %.2f km",i.getDoubleExtra("gap",0)));
        tariffSummary.setText(i.getStringExtra("tariffSummary"));

        boolean basePhase=i.getBooleanExtra("basePhase",false);
        int dRemain=i.getIntExtra("distanceRemain",0), dMax=i.getIntExtra("distanceMax",1), dProgress=i.getIntExtra("distanceProgress",0);
        distanceTitle.setText(basePhase ? "기본요금 포함거리까지" : "다음 거리요금까지");
        distanceRemain.setText(String.format(Locale.KOREA,"%,d m",dRemain));
        distanceBar.setMax(Math.max(1,dMax)); distanceBar.setProgress(Math.min(dMax,Math.max(0,dProgress)));

        boolean timeActive=i.getBooleanExtra("timeActive",false);
        int tRemain=i.getIntExtra("timeRemain",0), tMax=i.getIntExtra("timeMax",30), tProgress=i.getIntExtra("timeProgress",0);
        timeTitle.setText(timeActive ? "다음 시간요금까지 · 시간·거리 동시병산" : "시간요금 병산 대기");
        timeRemain.setText(timeActive ? String.format(Locale.KOREA,"%d 초",tRemain) : "—");
        timeBar.setMax(Math.max(1,tMax)); timeBar.setProgress(timeActive ? Math.min(tMax,Math.max(0,tProgress)) : 0);
        mode.setText(i.getStringExtra("mode") == null ? (timeActive ? "● 시간·거리 동시병산 중" : "● 거리 병산 중") : i.getStringExtra("mode"));
    }

    LinearLayout box(){
        LinearLayout b=new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setPadding(dp(12),dp(8),dp(12),dp(8)); b.setBackgroundColor(Color.rgb(245,245,245)); return b;
    }
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(Color.BLACK);v.setPadding(0,dp(4),0,dp(4));return v;}
    @Override protected void onDestroy(){try{unregisterReceiver(meterReceiver);}catch(Exception ignored){} super.onDestroy();}
}
